package com.example.testingdemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
